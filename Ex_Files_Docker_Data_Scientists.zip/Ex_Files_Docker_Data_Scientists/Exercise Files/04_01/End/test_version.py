import pandas
import seaborn

assert(pandas.__version__)=="0.24.2"
assert(seaborn.__version__)=="0.9.0"
